const express = require("express");
const router = express.Router();
const logger = require("../utils/logger");
const { processarFila } = require("../services/desligamentoService");

// Health check simples, útil para monitoramento (ex: Kubernetes liveness probe)
router.get("/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// Permite disparar o processamento manualmente (útil para testes ou
// para a abordagem de webhook mencionada no documento, seção 3.1).
// Em produção, proteger esta rota com autenticação.
router.post("/processar-agora", async (req, res) => {
  logger.info("Processamento manual da fila solicitado via API");
  try {
    await processarFila();
    res.json({ status: "processado" });
  } catch (erro) {
    res.status(500).json({ status: "erro", mensagem: erro.message });
  }
});

module.exports = router;
