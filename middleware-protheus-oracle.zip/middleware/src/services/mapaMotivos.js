const config = require("../config");

/**
 * Mapeamento de motivos de desligamento do Protheus para os lookup codes
 * de motivo de término usados no Oracle HCM Cloud.
 *
 * Os códigos de exemplo abaixo (VOLUNTARY, INVOLUNTARY etc.) são apenas
 * ilustrativos. Os valores reais dependem do lookup type configurado no
 * Oracle (geralmente algo como "TERMINATION_REASON") e precisam ser
 * confirmados com o time responsável pelo Oracle antes de ir para
 * produção.
 */
const MAPA_MOTIVOS = {
  DEMISSAO_SEM_JUSTA_CAUSA: "INVOLUNTARY",
  DEMISSAO_COM_JUSTA_CAUSA: "INVOLUNTARY_CAUSE",
  PEDIDO_DEMISSAO: "VOLUNTARY",
  TERMINO_CONTRATO: "END_OF_CONTRACT",
  APOSENTADORIA: "RETIREMENT",
};

function mapearMotivo(motivoProtheus) {
  return MAPA_MOTIVOS[motivoProtheus] || config.oracle.motivoPadrao;
}

module.exports = { mapearMotivo, MAPA_MOTIVOS };
