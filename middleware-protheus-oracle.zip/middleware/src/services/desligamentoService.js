const config = require("../config");
const logger = require("../utils/logger");
const protheus = require("./protheusClient");
const oracle = require("./oracleClient");
const { mapearMotivo } = require("./mapaMotivos");

/**
 * Processa um único desligamento: busca o colaborador no Oracle pelo CPF
 * e envia o desligamento. Erros de negócio (ex: colaborador não
 * encontrado) não devem ser tentados novamente automaticamente; erros de
 * rede/timeout sim, via a lógica de retry em `processarFila`.
 */
async function processarDesligamento(registro) {
  const { matricula, cpf, dataDesligamento, motivo } = registro;

  logger.info("Processando desligamento", { matricula });

  const personId = await oracle.buscarPersonIdPorCpf(cpf);
  const motivoOracle = mapearMotivo(motivo);

  await oracle.enviarDesligamento({
    personId,
    dataDesligamento,
    motivoOracle,
  });

  logger.info("Desligamento enviado ao Oracle com sucesso", { matricula, personId });
}

/**
 * Busca os desligamentos pendentes no Protheus e processa um a um,
 * confirmando o resultado de volta. Erros em um registro não interrompem
 * o processamento dos demais.
 */
async function processarFila() {
  let pendentes;
  try {
    pendentes = await protheus.buscarDesligamentosPendentes();
  } catch (erro) {
    logger.error("Não foi possível obter a fila de desligamentos do Protheus; tentando novamente no próximo ciclo");
    return;
  }

  if (pendentes.length === 0) {
    logger.info("Nenhum desligamento pendente nesta rodada");
    return;
  }

  logger.info(`${pendentes.length} desligamento(s) pendente(s) encontrado(s)`);

  for (const registro of pendentes) {
    try {
      await processarDesligamento(registro);
      await protheus.confirmarProcessamento(registro.matricula, "ENVIADO");
    } catch (erro) {
      await tratarFalha(registro, erro);
    }
  }
}

/**
 * Decide o que fazer quando o processamento de um registro falha:
 * registra o erro e, se o número de tentativas ainda não atingiu o
 * limite configurado, deixa o registro como pendente para ser
 * reprocessado no próximo ciclo. Caso contrário, marca como erro
 * definitivo e notifica um responsável.
 */
async function tratarFalha(registro, erro) {
  const tentativas = (registro.tentativas || 0) + 1;

  logger.error("Falha ao processar desligamento", {
    matricula: registro.matricula,
    tentativas,
    mensagem: erro.message,
  });

  if (tentativas >= config.integracao.maxTentativas) {
    await protheus.confirmarProcessamento(
      registro.matricula,
      "ERRO",
      `Falha definitiva após ${tentativas} tentativas: ${erro.message}`
    );
    await notificarResponsavel(registro, erro, tentativas);
  }
  // Se ainda não atingiu o limite, não confirma nada — o registro
  // continua "PENDENTE" no Protheus e será buscado novamente no próximo
  // ciclo de polling (o contador de tentativas deve ser incrementado do
  // lado Protheus, ou enviado e armazenado pelo próprio middleware,
  // dependendo de onde vocês decidirem manter esse estado).
}

/**
 * Notificação de erro definitivo. Esqueleto simples — substituir pelo
 * mecanismo real (e-mail, Slack, Teams, etc.) usado pelo time.
 */
async function notificarResponsavel(registro, erro, tentativas) {
  logger.warn("ALERTA: desligamento não pôde ser sincronizado com o Oracle após múltiplas tentativas", {
    matricula: registro.matricula,
    tentativas,
    destino: config.integracao.emailNotificacao,
    mensagem: erro.message,
  });
  // TODO: integrar com serviço de e-mail/Slack/Teams real.
}

module.exports = { processarFila, processarDesligamento };
