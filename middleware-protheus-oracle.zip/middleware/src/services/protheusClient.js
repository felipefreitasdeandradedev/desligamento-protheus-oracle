const axios = require("axios");
const config = require("../config");
const logger = require("../utils/logger");

const client = axios.create({
  baseURL: config.protheus.baseUrl,
  timeout: 15000,
  headers: {
    Authorization: `Bearer ${config.protheus.apiKey}`,
    "Content-Type": "application/json",
  },
});

/**
 * Busca os desligamentos pendentes de envio ao Oracle.
 * Endpoint a ser exposto pelo Protheus via TLPP/Rest Framework.
 *
 * Resposta esperada (ajustar conforme contrato real definido com o
 * consultor Protheus):
 * [
 *   { matricula, cpf, dataDesligamento, motivo }
 * ]
 */
async function buscarDesligamentosPendentes() {
  try {
    const { data } = await client.get("/api/desligamentos/pendentes");
    return data || [];
  } catch (erro) {
    logger.error("Falha ao consultar desligamentos pendentes no Protheus", {
      mensagem: erro.message,
      status: erro.response?.status,
    });
    throw erro;
  }
}

/**
 * Informa ao Protheus o resultado do processamento de um desligamento,
 * para que ele não seja reenviado indevidamente.
 *
 * @param {string} matricula
 * @param {"ENVIADO"|"ERRO"} status
 * @param {string} [detalhe] mensagem de erro, se houver
 */
async function confirmarProcessamento(matricula, status, detalhe = null) {
  try {
    await client.post("/api/desligamentos/confirmar", {
      matricula,
      status,
      detalhe,
    });
  } catch (erro) {
    // Se essa chamada falhar, o registro pode ser reprocessado na próxima
    // rodada de polling. Isso é aceitável (idempotência é tratada do lado
    // Oracle/PersonId), mas vale alertar.
    logger.error("Falha ao confirmar processamento de volta ao Protheus", {
      matricula,
      status,
      mensagem: erro.message,
    });
  }
}

module.exports = {
  buscarDesligamentosPendentes,
  confirmarProcessamento,
};
