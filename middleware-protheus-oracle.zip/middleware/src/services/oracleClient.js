const axios = require("axios");
const qs = require("node:querystring");
const config = require("../config");
const logger = require("../utils/logger");

let tokenCache = { accessToken: null, expiraEm: 0 };

/**
 * Obtém um access token OAuth2 (fluxo Client Credentials) e mantém em
 * cache em memória até pouco antes de expirar, evitando autenticar de
 * novo em toda chamada.
 */
async function obterToken() {
  const agora = Date.now();
  if (tokenCache.accessToken && agora < tokenCache.expiraEm) {
    return tokenCache.accessToken;
  }

  const body = {
    grant_type: "client_credentials",
  };
  if (config.oracle.scope) body.scope = config.oracle.scope;

  try {
    const { data } = await axios.post(
      config.oracle.tokenUrl,
      qs.stringify(body),
      {
        auth: {
          username: config.oracle.clientId,
          password: config.oracle.clientSecret,
        },
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        timeout: 15000,
      }
    );

    tokenCache = {
      accessToken: data.access_token,
      // margem de segurança de 60s antes da expiração real
      expiraEm: agora + (data.expires_in - 60) * 1000,
    };
    return tokenCache.accessToken;
  } catch (erro) {
    logger.error("Falha ao autenticar no Oracle (OAuth2)", {
      mensagem: erro.message,
      status: erro.response?.status,
    });
    throw erro;
  }
}

async function clienteOracle() {
  const token = await obterToken();
  return axios.create({
    baseURL: config.oracle.baseUrl,
    timeout: 20000,
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/vnd.oracle.adf.resourceitem+json",
    },
  });
}

/**
 * Localiza o PersonId no Oracle a partir do CPF, já que a matrícula do
 * Protheus não existe como identificador nativo no Oracle. O nome do
 * recurso e o nome do campo de identificador nacional devem ser
 * confirmados com o time responsável pelo Oracle (varia por versão e
 * configuração de Person Number / National Identifier).
 */
async function buscarPersonIdPorCpf(cpf) {
  const http = await clienteOracle();
  try {
    const { data } = await http.get("/hcmRestApi/resources/11.13.18.05/workers", {
      params: {
        q: `NationalIdentifierNumber='${cpf}'`,
        onlyData: true,
        fields: "PersonId,PersonNumber",
      },
    });

    const encontrado = data?.items?.[0];
    if (!encontrado) {
      throw new Error(`Nenhum colaborador encontrado no Oracle para o CPF informado`);
    }
    return encontrado.PersonId;
  } catch (erro) {
    logger.error("Falha ao buscar PersonId no Oracle", {
      mensagem: erro.message,
      status: erro.response?.status,
    });
    throw erro;
  }
}

/**
 * Envia o desligamento ao Oracle Cloud HCM.
 *
 * IMPORTANTE: o endpoint exato (workRelationships/.../terminations) e os
 * campos obrigatórios variam de acordo com a versão do Oracle HCM Cloud
 * em uso. Este é um esqueleto ilustrativo baseado no padrão mais comum
 * — deve ser validado e ajustado com a documentação REST da versão
 * específica do ambiente Oracle de vocês.
 */
async function enviarDesligamento({ personId, dataDesligamento, motivoOracle }) {
  const http = await clienteOracle();
  try {
    const { data } = await http.post(
      `/hcmRestApi/resources/11.13.18.05/workers/${personId}/child/workRelationships`,
      {
        TerminationDate: dataDesligamento, // formato esperado: YYYY-MM-DD
        TerminationReasonCode: motivoOracle,
      }
    );
    return data;
  } catch (erro) {
    logger.error("Falha ao enviar desligamento ao Oracle", {
      personId,
      mensagem: erro.message,
      status: erro.response?.status,
      detalhe: erro.response?.data,
    });
    throw erro;
  }
}

module.exports = {
  buscarPersonIdPorCpf,
  enviarDesligamento,
};
