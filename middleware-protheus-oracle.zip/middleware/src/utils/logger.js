const winston = require("winston");
const config = require("../config");

// Logger estruturado. Em produção, considere enviar esses logs para um
// sistema centralizado (ex: ELK, Datadog, CloudWatch), já que se trata
// de uma integração de dados de RH e precisa de trilha de auditoria.
const logger = winston.createLogger({
  level: config.app.logLevel,
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  defaultMeta: { servico: "integracao-protheus-oracle" },
  transports: [
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize(),
        winston.format.simple()
      ),
    }),
    new winston.transports.File({ filename: "logs/erro.log", level: "error" }),
    new winston.transports.File({ filename: "logs/integracao.log" }),
  ],
});

module.exports = logger;
