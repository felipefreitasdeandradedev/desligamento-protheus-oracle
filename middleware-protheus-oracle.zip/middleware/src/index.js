const express = require("express");
const cron = require("node-cron");
const config = require("./config");
const logger = require("./utils/logger");
const routes = require("./routes");
const { processarFila } = require("./services/desligamentoService");

const app = express();
app.use(express.json());
app.use(routes);

app.listen(config.app.port, () => {
  logger.info(`Middleware Protheus → Oracle iniciado na porta ${config.app.port}`);
});

// Agenda o polling periódico conforme expressão cron definida em
// POLLING_CRON (padrão: a cada 5 minutos). Essa é a forma mais simples
// e resiliente de iniciar — ver seção 3.1 do documento de arquitetura
// para a alternativa via webhook.
cron.schedule(config.integracao.pollingCron, () => {
  logger.info("Iniciando ciclo de polling da fila de desligamentos");
  processarFila().catch((erro) => {
    logger.error("Erro inesperado no ciclo de polling", { mensagem: erro.message });
  });
});

// Executa uma vez imediatamente ao iniciar, para não esperar o primeiro
// intervalo do cron.
processarFila().catch((erro) => {
  logger.error("Erro na execução inicial do processamento", { mensagem: erro.message });
});
