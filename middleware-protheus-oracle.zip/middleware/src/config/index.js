require("dotenv").config();

function obrigatoria(nome) {
  const valor = process.env[nome];
  if (!valor && process.env.NODE_ENV === "production") {
    throw new Error(`Variável de ambiente obrigatória ausente: ${nome}`);
  }
  return valor;
}

module.exports = {
  protheus: {
    baseUrl: obrigatoria("PROTHEUS_BASE_URL"),
    apiKey: obrigatoria("PROTHEUS_API_KEY"),
  },
  oracle: {
    baseUrl: obrigatoria("ORACLE_BASE_URL"),
    tokenUrl: obrigatoria("ORACLE_OAUTH_TOKEN_URL"),
    clientId: obrigatoria("ORACLE_CLIENT_ID"),
    clientSecret: obrigatoria("ORACLE_CLIENT_SECRET"),
    scope: process.env.ORACLE_OAUTH_SCOPE || "",
    motivoPadrao: process.env.ORACLE_MOTIVO_PADRAO || "VOLUNTARY",
  },
  integracao: {
    pollingCron: process.env.POLLING_CRON || "*/5 * * * *",
    maxTentativas: parseInt(process.env.MAX_TENTATIVAS || "5", 10),
    emailNotificacao: process.env.NOTIFICACAO_EMAIL_DESTINO || null,
  },
  app: {
    port: parseInt(process.env.PORT || "3000", 10),
    logLevel: process.env.LOG_LEVEL || "info",
    env: process.env.NODE_ENV || "development",
  },
};
